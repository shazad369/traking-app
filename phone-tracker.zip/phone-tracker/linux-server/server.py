#!/usr/bin/env python3
"""
Phone Tracker Server
Run this on your Linux computer.
Phone will send location, IP, WiFi name, battery % to this server.
"""

from http.server import HTTPServer, BaseHTTPRequestHandler
import json
import datetime
import os
import base64

# =============================================
# CONFIG - শুধু এই দুটো পরিবর্তন করো
PORT = 8080
SAVE_FOLDER = "./received_data"
# =============================================

os.makedirs(SAVE_FOLDER, exist_ok=True)
os.makedirs(f"{SAVE_FOLDER}/photos", exist_ok=True)

class TrackerHandler(BaseHTTPRequestHandler):

    def do_POST(self):
        content_length = int(self.headers.get('Content-Length', 0))
        body = self.rfile.read(content_length)

        try:
            data = json.loads(body.decode('utf-8'))
        except Exception as e:
            self.send_response(400)
            self.end_headers()
            return

        now = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")

        print("\n" + "="*50)
        print(f"📱 PHONE CONNECTED! [{now}]")
        print("="*50)
        print(f"📍 Location   : {data.get('latitude', 'N/A')}, {data.get('longitude', 'N/A')}")
        print(f"🌐 Phone IP   : {data.get('phone_ip', 'N/A')}")
        print(f"📶 WiFi Name  : {data.get('wifi_ssid', 'N/A')}")
        print(f"🔋 Battery    : {data.get('battery', 'N/A')}%")
        print(f"🗺️  Maps Link  : https://maps.google.com/?q={data.get('latitude', '')},{data.get('longitude', '')}")
        print("="*50)

        # Save to log file
        log_entry = {
            "time": now,
            "latitude": data.get("latitude"),
            "longitude": data.get("longitude"),
            "phone_ip": data.get("phone_ip"),
            "wifi_ssid": data.get("wifi_ssid"),
            "battery": data.get("battery"),
            "maps_link": f"https://maps.google.com/?q={data.get('latitude', '')},{data.get('longitude', '')}"
        }

        log_file = f"{SAVE_FOLDER}/log.json"
        logs = []
        if os.path.exists(log_file):
            with open(log_file, "r") as f:
                try:
                    logs = json.load(f)
                except:
                    logs = []
        logs.append(log_entry)
        with open(log_file, "w") as f:
            json.dump(logs, f, indent=2, ensure_ascii=False)

        # Save photo if available
        photo_data = data.get("photo")
        if photo_data:
            photo_filename = f"{SAVE_FOLDER}/photos/photo_{datetime.datetime.now().strftime('%Y%m%d_%H%M%S')}.jpg"
            with open(photo_filename, "wb") as f:
                f.write(base64.b64decode(photo_data))
            print(f"📸 Photo saved: {photo_filename}")

        # Desktop notification (Linux)
        try:
            os.system(f'notify-send "📱 Phone Found!" "Location: {data.get(\"latitude\", \"N/A\")}, {data.get(\"longitude\", \"N/A\")}\nWiFi: {data.get(\"wifi_ssid\", \"N/A\")}"')
        except:
            pass

        self.send_response(200)
        self.send_header('Content-Type', 'application/json')
        self.end_headers()
        self.wfile.write(json.dumps({"status": "ok"}).encode())

    def log_message(self, format, *args):
        pass  # Suppress default HTTP logs

if __name__ == "__main__":
    print("="*50)
    print("🖥️  Phone Tracker Server চালু হচ্ছে...")
    print(f"🌐 Port: {PORT}")
    print(f"💾 Data save হবে: {SAVE_FOLDER}/")
    print("📱 Phone connect হলে এখানে দেখাবে")
    print("⛔ বন্ধ করতে: Ctrl+C")
    print("="*50 + "\n")

    server = HTTPServer(('0.0.0.0', PORT), TrackerHandler)
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        print("\n⛔ Server বন্ধ হয়েছে।")
