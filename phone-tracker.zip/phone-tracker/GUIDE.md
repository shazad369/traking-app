# 📱 Phone Tracker - সম্পূর্ণ গাইড

## ধাপ ১: তোমার Linux IP বের করো

Terminal খুলে লেখো:
```
ip addr show
```
`inet 192.168.x.x` এই format-এ তোমার IP দেখাবে। এটা note করো।

---

## ধাপ ২: Config.java তে IP দাও

`android-app/app/src/main/java/com/tracker/phonetracker/Config.java` ফাইলটা খোলো।

এই line টা পরিবর্তন করো:
```java
public static final String SERVER_IP = "YOUR_LINUX_IP_HERE";
```
তোমার IP দিয়ে, যেমন:
```java
public static final String SERVER_IP = "192.168.1.100";
```

---

## ধাপ ৩: Android Studio দিয়ে APK বানাও

1. **Android Studio** download করো: https://developer.android.com/studio
2. `android-app` folder টা Android Studio তে open করো
3. উপরে **Build → Build Bundle(s)/APK(s) → Build APK(s)** click করো
4. APK তৈরি হবে: `app/build/outputs/apk/debug/app-debug.apk`

---

## ধাপ ৪: Phone-এ APK install করো

1. APK file টা phone-এ transfer করো (USB বা WhatsApp দিয়ে)
2. Phone-এ **Settings → Unknown sources** চালু করো
3. APK তে tap করে install করো
4. App open করো → Permission দাও → App বন্ধ হয়ে যাবে (এটা normal!)

---

## ধাপ ৫: Linux-এ Server চালু করো

VS Code-এ terminal খুলে:
```bash
cd linux-server
python3 server.py
```

---

## ✅ এখন থেকে:

Phone যখনই **WiFi connect** করবে, তোমার terminal-এ দেখাবে:

```
==================================================
📱 PHONE CONNECTED! [2024-01-15 14:30:22]
==================================================
📍 Location   : 23.8103, 90.4125
🌐 Phone IP   : 192.168.1.105
📶 WiFi Name  : HomeWiFi
🔋 Battery    : 67%
🗺️  Maps Link  : https://maps.google.com/?q=23.8103,90.4125
==================================================
```

সব data save হবে: `linux-server/received_data/log.json`

---

## ⚠️ গুরুত্বপূর্ণ নোট:

- Phone এবং Computer **একই WiFi-তে** থাকলে Local IP দাও
- Phone **অন্য WiFi-তে** থাকলে তোমার computer-এর **Public IP** দাও
  - Public IP বের করতে: https://whatismyip.com
  - Router-এ **Port Forwarding** করতে হবে: Port 8080 → তোমার Linux IP
