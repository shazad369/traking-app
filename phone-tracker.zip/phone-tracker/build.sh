#!/bin/bash

# ============================================
#   Phone Tracker - Auto Setup & Build Script
#   শুধু এই script run করো, বাকি সব automatic!
# ============================================

set -e

RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'

echo ""
echo -e "${BLUE}╔══════════════════════════════════════╗${NC}"
echo -e "${BLUE}║     Phone Tracker - Auto Builder     ║${NC}"
echo -e "${BLUE}╚══════════════════════════════════════╝${NC}"
echo ""

# ── ধাপ ১: Server IP নাও ──────────────────────────────────
echo -e "${YELLOW}📡 তোমার Linux computer-এর IP কী?${NC}"
echo -e "   (Terminal-এ ${GREEN}ip addr show${NC} দিয়ে দেখতে পারো)"
echo -n "   IP দাও: "
read SERVER_IP

if [ -z "$SERVER_IP" ]; then
    echo -e "${RED}❌ IP দাওনি! আবার চালাও।${NC}"
    exit 1
fi

echo ""
echo -e "${GREEN}✓ IP set হয়েছে: $SERVER_IP${NC}"
echo ""

# ── ধাপ ২: Config.java তে IP বসাও ────────────────────────
CONFIG_FILE="./android-app/app/src/main/java/com/tracker/phonetracker/Config.java"
sed -i "s/YOUR_LINUX_IP_HERE/$SERVER_IP/g" "$CONFIG_FILE"
echo -e "${GREEN}✓ Config.java আপডেট হয়েছে${NC}"

# ── ধাপ ৩: JDK install করো ───────────────────────────────
echo ""
echo -e "${YELLOW}☕ Java JDK check করছি...${NC}"

if command -v java &> /dev/null; then
    echo -e "${GREEN}✓ Java আগে থেকেই আছে$(java -version 2>&1 | head -1)${NC}"
else
    echo -e "${YELLOW}   Java নেই, install করছি...${NC}"
    sudo apt-get update -qq
    sudo apt-get install -y openjdk-17-jdk -qq
    echo -e "${GREEN}✓ Java install হয়েছে${NC}"
fi

# ── ধাপ ৪: Android SDK install করো ──────────────────────
echo ""
echo -e "${YELLOW}📦 Android SDK check করছি...${NC}"

ANDROID_SDK_ROOT="$HOME/android-sdk"
CMDLINE_TOOLS="$ANDROID_SDK_ROOT/cmdline-tools/latest"

if [ ! -d "$CMDLINE_TOOLS" ]; then
    echo -e "${YELLOW}   Android SDK নেই, download করছি... (একটু সময় লাগবে)${NC}"

    mkdir -p "$ANDROID_SDK_ROOT/cmdline-tools"
    cd /tmp

    wget -q --show-progress \
        "https://dl.google.com/android/repository/commandlinetools-linux-11076708_latest.zip" \
        -O cmdline-tools.zip

    unzip -q cmdline-tools.zip
    mv cmdline-tools "$ANDROID_SDK_ROOT/cmdline-tools/latest"
    rm cmdline-tools.zip

    cd - > /dev/null
    echo -e "${GREEN}✓ Android SDK download হয়েছে${NC}"
else
    echo -e "${GREEN}✓ Android SDK আগে থেকেই আছে${NC}"
fi

# SDK path set করো
export ANDROID_SDK_ROOT="$HOME/android-sdk"
export PATH="$ANDROID_SDK_ROOT/cmdline-tools/latest/bin:$ANDROID_SDK_ROOT/platform-tools:$PATH"

# ── ধাপ ৫: Android Build Tools install করো ───────────────
echo ""
echo -e "${YELLOW}🔧 Build tools install করছি...${NC}"

yes | sdkmanager --licenses > /dev/null 2>&1 || true
sdkmanager "platforms;android-34" "build-tools;34.0.0" --silent

echo -e "${GREEN}✓ Build tools ready${NC}"

# local.properties আপডেট করো
echo "sdk.dir=$ANDROID_SDK_ROOT" > ./android-app/local.properties

# ── ধাপ ৬: Gradle wrapper download করো ───────────────────
echo ""
echo -e "${YELLOW}🐘 Gradle setup করছি...${NC}"

cd android-app

if [ ! -f "gradlew" ]; then
    wget -q "https://raw.githubusercontent.com/gradle/gradle/master/gradlew" -O gradlew
    chmod +x gradlew
fi

# ── ধাপ ৭: APK Build করো ────────────────────────────────
echo ""
echo -e "${YELLOW}🔨 APK build করছি... (২-৩ মিনিট লাগতে পারে)${NC}"

export ANDROID_SDK_ROOT="$HOME/android-sdk"
./gradlew assembleDebug --quiet

APK_PATH="app/build/outputs/apk/debug/app-debug.apk"

if [ -f "$APK_PATH" ]; then
    cp "$APK_PATH" ../tracker.apk
    cd ..
    echo ""
    echo -e "${GREEN}╔══════════════════════════════════════╗${NC}"
    echo -e "${GREEN}║         ✅ APK তৈরি হয়েছে!          ║${NC}"
    echo -e "${GREEN}╚══════════════════════════════════════╝${NC}"
    echo ""
    echo -e "📱 APK location: ${BLUE}$(pwd)/tracker.apk${NC}"
    echo ""
    echo -e "${YELLOW}এখন কী করবে:${NC}"
    echo -e "  ১. ${GREEN}tracker.apk${NC} phone-এ transfer করো (USB/WhatsApp)"
    echo -e "  ২. Phone-এ install করো"
    echo -e "  ৩. ${GREEN}python3 linux-server/server.py${NC} চালাও"
    echo -e "  ৪. Phone WiFi connect করলেই তোমার terminal-এ দেখাবে! 🎯"
    echo ""
else
    cd ..
    echo -e "${RED}❌ APK build হয়নি। Error দেখো উপরে।${NC}"
    exit 1
fi
